interface AdBannerProps {
  position: 'top' | 'middle' | 'footer';
}

export function AdBanner({ position }: AdBannerProps) {
  const heights: Record<string, string> = {
    top: 'h-24',
    middle: 'h-32',
    footer: 'h-20',
  };

  return (
    <div className={`bg-slate-800/50 border border-green-500/20 rounded-lg ${heights[position]} flex items-center justify-center`}>
      <div className="text-center">
        <p className="text-gray-500 font-medium">Advertisement Space</p>
        <p className="text-gray-600 text-sm mt-1">{position === 'top' ? 'Header Ad' : position === 'middle' ? 'Content Ad' : 'Footer Ad'}</p>
      </div>
    </div>
  );
}
