import { Loader2 } from 'lucide-react';

export function Loader() {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <Loader2 className="w-12 h-12 text-green-500 animate-spin" />
      <p className="mt-4 text-gray-400">Fetching video details...</p>
    </div>
  );
}
