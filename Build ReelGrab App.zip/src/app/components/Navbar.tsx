import { Video } from 'lucide-react';

export function Navbar() {
  return (
    <nav className="border-b border-green-500/20 bg-slate-900/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 bg-green-500 rounded-lg">
            <Video className="w-6 h-6 text-slate-900" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">ReelGrab</h1>
            <p className="text-xs text-green-400">Social Media Downloader</p>
          </div>
        </div>
      </div>
    </nav>
  );
}
