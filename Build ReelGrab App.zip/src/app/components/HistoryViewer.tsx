import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { History, X } from 'lucide-react';
import { projectId, publicAnonKey } from '/utils/supabase/info';

interface HistoryItem {
  url: string;
  platform: string;
  timestamp: string;
  title: string;
}

export function HistoryViewer() {
  const [isOpen, setIsOpen] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-22961a83/history`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );
      const data = await response.json();
      setHistory(data.history || []);
    } catch (error) {
      console.error('Failed to fetch history:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchHistory();
    }
  }, [isOpen]);

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <>
      {/* Toggle Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="bg-green-500 hover:bg-green-600 text-slate-900 font-semibold shadow-lg"
          size="lg"
        >
          <History className="w-5 h-5 mr-2" />
          History
        </Button>
      </div>

      {/* History Panel */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-800 rounded-lg max-w-2xl w-full max-h-[80vh] overflow-hidden border border-green-500/20">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-green-500/20">
              <h2 className="text-white text-2xl font-bold flex items-center gap-2">
                <History className="w-6 h-6 text-green-500" />
                Download History
              </h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            {/* Content */}
            <div className="overflow-y-auto max-h-[calc(80vh-80px)] p-6">
              {loading ? (
                <div className="text-center py-12">
                  <p className="text-gray-400">Loading history...</p>
                </div>
              ) : history.length === 0 ? (
                <div className="text-center py-12">
                  <History className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">No download history yet</p>
                  <p className="text-gray-500 text-sm mt-2">
                    Your downloads will appear here
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {history.map((item, index) => (
                    <div
                      key={index}
                      className="bg-slate-900 rounded-lg p-4 border border-slate-700 hover:border-green-500/30 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <p className="text-white font-medium truncate">
                            {item.title}
                          </p>
                          <p className="text-gray-400 text-sm mt-1 truncate">
                            {item.url}
                          </p>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <span className={`px-2 py-1 rounded text-xs font-semibold ${
                            item.platform === 'TikTok' ? 'bg-pink-500/20 text-pink-300' :
                            item.platform === 'Instagram' ? 'bg-purple-500/20 text-purple-300' :
                            'bg-blue-500/20 text-blue-300'
                          }`}>
                            {item.platform}
                          </span>
                          <span className="text-gray-500 text-xs whitespace-nowrap">
                            {formatDate(item.timestamp)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
