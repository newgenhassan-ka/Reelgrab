import { Button } from './ui/button';
import { toast } from 'sonner';

interface SampleUrlsProps {
  onSelectUrl: (url: string) => void;
}

export function SampleUrls({ onSelectUrl }: SampleUrlsProps) {
  const sampleUrls = [
    {
      platform: 'TikTok',
      url: 'https://www.tiktok.com/@user/video/1234567890',
      color: 'bg-pink-500',
    },
    {
      platform: 'Instagram',
      url: 'https://www.instagram.com/reel/ABC123DEF456/',
      color: 'bg-purple-500',
    },
    {
      platform: 'Facebook',
      url: 'https://www.facebook.com/watch/?v=123456789012345',
      color: 'bg-blue-500',
    },
  ];

  const handleSelectUrl = (url: string, platform: string) => {
    onSelectUrl(url);
    toast.success(`Sample ${platform} URL loaded`);
  };

  return (
    <div className="max-w-2xl mx-auto mb-8">
      <div className="bg-slate-800/30 border border-green-500/20 rounded-lg p-4">
        <p className="text-gray-400 text-sm mb-3 text-center">
          Try with sample URLs:
        </p>
        <div className="flex flex-wrap gap-2 justify-center">
          {sampleUrls.map((sample) => (
            <Button
              key={sample.platform}
              size="sm"
              variant="outline"
              onClick={() => handleSelectUrl(sample.url, sample.platform)}
              className="border-green-500/30 text-gray-300 hover:bg-green-500/10"
            >
              <span className={`w-2 h-2 rounded-full ${sample.color} mr-2`}></span>
              {sample.platform}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}
