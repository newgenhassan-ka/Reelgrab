import { Download, Copy, Check } from 'lucide-react';
import { Button } from './ui/button';
import { useState } from 'react';

interface Format {
  quality: string;
  url: string;
  size: string;
  type: 'video' | 'audio';
}

interface DownloadOptionsProps {
  formats: Format[];
  onDownload: (url: string, quality: string) => void;
}

export function DownloadOptions({ formats, onDownload }: DownloadOptionsProps) {
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  const handleCopy = async (url: string) => {
    await navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  const videoFormats = formats.filter(f => f.type === 'video');
  const audioFormats = formats.filter(f => f.type === 'audio');

  return (
    <div className="space-y-4">
      {videoFormats.length > 0 && (
        <div className="bg-slate-800 rounded-lg p-6 border border-green-500/20">
          <h3 className="text-white font-semibold text-lg mb-4 flex items-center gap-2">
            <Download className="w-5 h-5 text-green-500" />
            Video Formats
          </h3>
          <div className="space-y-3">
            {videoFormats.map((format, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-slate-900 rounded-lg border border-slate-700">
                <div className="flex-1">
                  <p className="text-white font-medium">{format.quality}</p>
                  <p className="text-gray-400 text-sm">{format.size}</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopy(format.url)}
                    className="border-green-500/30 text-green-400 hover:bg-green-500/10"
                  >
                    {copiedUrl === format.url ? (
                      <>
                        <Check className="w-4 h-4 mr-1" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-1" />
                        Copy Link
                      </>
                    )}
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => onDownload(format.url, format.quality)}
                    className="bg-green-500 hover:bg-green-600 text-slate-900 font-semibold"
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {audioFormats.length > 0 && (
        <div className="bg-slate-800 rounded-lg p-6 border border-green-500/20">
          <h3 className="text-white font-semibold text-lg mb-4 flex items-center gap-2">
            <Download className="w-5 h-5 text-green-500" />
            Audio Formats (MP3)
          </h3>
          <div className="space-y-3">
            {audioFormats.map((format, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-slate-900 rounded-lg border border-slate-700">
                <div className="flex-1">
                  <p className="text-white font-medium">{format.quality}</p>
                  <p className="text-gray-400 text-sm">{format.size}</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopy(format.url)}
                    className="border-green-500/30 text-green-400 hover:bg-green-500/10"
                  >
                    {copiedUrl === format.url ? (
                      <>
                        <Check className="w-4 h-4 mr-1" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-1" />
                        Copy Link
                      </>
                    )}
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => onDownload(format.url, format.quality)}
                    className="bg-green-500 hover:bg-green-600 text-slate-900 font-semibold"
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
