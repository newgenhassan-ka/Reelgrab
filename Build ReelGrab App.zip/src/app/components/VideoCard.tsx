import { ImageWithFallback } from './figma/ImageWithFallback';

interface VideoCardProps {
  title: string;
  thumbnail: string;
  platform: string;
}

export function VideoCard({ title, thumbnail, platform }: VideoCardProps) {
  const platformColors: Record<string, string> = {
    tiktok: 'bg-pink-500',
    instagram: 'bg-purple-500',
    facebook: 'bg-blue-500',
  };

  const platformColor = platformColors[platform.toLowerCase()] || 'bg-gray-500';

  return (
    <div className="bg-slate-800 rounded-lg overflow-hidden border border-green-500/20 shadow-lg">
      <div className="relative aspect-video bg-slate-900">
        <ImageWithFallback
          src={thumbnail}
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className={`absolute top-3 right-3 px-3 py-1 ${platformColor} rounded-full text-white text-xs font-semibold uppercase`}>
          {platform}
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-white font-semibold text-lg line-clamp-2">{title}</h3>
      </div>
    </div>
  );
}
