import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Loader } from './components/Loader';
import { VideoCard } from './components/VideoCard';
import { DownloadOptions } from './components/DownloadOptions';
import { AdBanner } from './components/AdBanner';
import { SampleUrls } from './components/SampleUrls';
import { HistoryViewer } from './components/HistoryViewer';
import { Input } from './components/ui/input';
import { Button } from './components/ui/button';
import { Download, AlertCircle, RotateCcw, Clipboard } from 'lucide-react';
import { projectId, publicAnonKey } from '/utils/supabase/info';
import { toast } from 'sonner';
import { Toaster } from './components/ui/sonner';

interface VideoData {
  title: string;
  thumbnail: string;
  platform: string;
  formats: Array<{
    quality: string;
    url: string;
    size: string;
    type: 'video' | 'audio';
  }>;
}

export default function App() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [videoData, setVideoData] = useState<VideoData | null>(null);

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text);
      toast.success('URL pasted from clipboard!');
    } catch (err) {
      toast.error('Failed to read clipboard. Please paste manually.');
    }
  };

  const handleFetchVideo = async () => {
    if (!url.trim()) {
      setError('Please enter a video URL');
      return;
    }

    setLoading(true);
    setError(null);
    setVideoData(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-22961a83/download`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ url }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch video');
      }

      setVideoData(data);
      toast.success('Video details fetched successfully!');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An error occurred';
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = (downloadUrl: string, quality: string) => {
    // Create a temporary anchor element to trigger download
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = `video_${quality}.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success(`Download started: ${quality}`);
  };

  const handleReset = () => {
    setUrl('');
    setVideoData(null);
    setError(null);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !loading) {
      handleFetchVideo();
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Toaster position="top-right" />
      <HistoryViewer />
      
      <Navbar />

      {/* Top Ad Banner */}
      <div className="container mx-auto px-4 mt-6">
        <AdBanner position="top" />
      </div>

      {/* Hero Section */}
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Download Videos <span className="text-green-500">Instantly</span>
          </h2>
          <p className="text-gray-400 text-lg">
            Download videos from TikTok, Instagram, and Facebook in high quality.
            Fast, free, and easy to use.
          </p>
        </div>

        {/* Input Section */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 flex gap-2">
              <Input
                type="text"
                placeholder="Paste video URL here (TikTok, Instagram, Facebook)"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyPress={handleKeyPress}
                className="bg-slate-800 border-green-500/30 text-white placeholder:text-gray-500 focus:border-green-500"
                disabled={loading}
              />
              <Button
                size="icon"
                variant="outline"
                onClick={handlePaste}
                className="border-green-500/30 text-green-400 hover:bg-green-500/10"
                title="Paste from clipboard"
              >
                <Clipboard className="w-4 h-4" />
              </Button>
            </div>
            <Button
              onClick={handleFetchVideo}
              disabled={loading}
              className="bg-green-500 hover:bg-green-600 text-slate-900 font-semibold px-8"
            >
              <Download className="w-5 h-5 mr-2" />
              {loading ? 'Processing...' : 'Download'}
            </Button>
          </div>

          {error && (
            <div className="mt-4 p-4 bg-red-500/10 border border-red-500/30 rounded-lg flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 mt-0.5" />
              <div className="flex-1">
                <p className="text-red-400 font-medium">Error</p>
                <p className="text-red-300 text-sm mt-1">{error}</p>
              </div>
            </div>
          )}
        </div>

        {/* Sample URLs - Only show when no video is loaded */}
        {!videoData && !loading && <SampleUrls onSelectUrl={setUrl} />}

        {/* Loading State */}
        {loading && <Loader />}

        {/* Video Preview and Download Options */}
        {videoData && !loading && (
          <div className="max-w-3xl mx-auto space-y-6">
            <VideoCard
              title={videoData.title}
              thumbnail={videoData.thumbnail}
              platform={videoData.platform}
            />

            {/* Middle Ad Banner */}
            <AdBanner position="middle" />

            <DownloadOptions
              formats={videoData.formats}
              onDownload={handleDownload}
            />

            <div className="flex justify-center">
              <Button
                onClick={handleReset}
                variant="outline"
                className="border-green-500/30 text-green-400 hover:bg-green-500/10"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Download Another Video
              </Button>
            </div>
          </div>
        )}

        {/* Info Section */}
        {!videoData && !loading && (
          <div className="max-w-3xl mx-auto mt-12">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-slate-800/50 border border-green-500/20 rounded-lg p-6 text-center">
                <div className="w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Download className="w-6 h-6 text-green-500" />
                </div>
                <h3 className="text-white font-semibold mb-2">Easy Download</h3>
                <p className="text-gray-400 text-sm">
                  Just paste the URL and download in seconds
                </p>
              </div>

              <div className="bg-slate-800/50 border border-green-500/20 rounded-lg p-6 text-center">
                <div className="w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-6 h-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                  </svg>
                </div>
                <h3 className="text-white font-semibold mb-2">High Quality</h3>
                <p className="text-gray-400 text-sm">
                  Download videos in up to 1080p HD quality
                </p>
              </div>

              <div className="bg-slate-800/50 border border-green-500/20 rounded-lg p-6 text-center">
                <div className="w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-6 h-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <h3 className="text-white font-semibold mb-2">Safe & Private</h3>
                <p className="text-gray-400 text-sm">
                  Your privacy is protected, no data is stored
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer Ad Banner */}
      <div className="container mx-auto px-4 mb-6">
        <AdBanner position="footer" />
      </div>

      {/* Footer */}
      <footer className="border-t border-green-500/20 bg-slate-900/50 backdrop-blur-sm py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <p className="text-gray-400 text-sm mb-4">
              <strong className="text-green-400">Disclaimer:</strong> This tool respects platform policies. 
              Users must follow copyright laws and only download content they have permission to use. 
              ReelGrab is intended for personal use and downloading publicly available content only.
            </p>
            <p className="text-gray-500 text-xs">
              © 2026 ReelGrab. All rights reserved. | Supports TikTok, Instagram & Facebook
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}